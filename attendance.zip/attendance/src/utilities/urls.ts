import { environment } from 'src/environments/environment';



export module Urls {

  const baseUrl: String = environment.baseUrl;
  

  export const teacherUrl: String = `${baseUrl}/attendance/v1/teacher`;
  export const studentUrl:String= `${baseUrl}/attendance/v1/student`;
  export const attendanceUrl:String=`${baseUrl}/attendance/v1/attendancedetails`

}