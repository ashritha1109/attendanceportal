import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttendancerepoComponent } from './attendancerepo.component';

describe('AttendancerepoComponent', () => {
  let component: AttendancerepoComponent;
  let fixture: ComponentFixture<AttendancerepoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AttendancerepoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AttendancerepoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
