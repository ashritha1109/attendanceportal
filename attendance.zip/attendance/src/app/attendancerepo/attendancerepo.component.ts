import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-attendancerepo',
  templateUrl: './attendancerepo.component.html',
  styleUrls: ['./attendancerepo.component.css'],
})
export class AttendancerepoComponent implements OnInit {
  currentDate: any = new Date();
  timestamp: any = this.currentDate.getTime();
  currdate: any = this.currentDate.toLocaleDateString();
  attendancedetails: any;
  marking:string="";
  constructor(private service: DataService) {}

  ngOnInit(): void {
    this.service.getAttendance().subscribe((data) => {
     console.log(data);
     this.attendancedetails=data;
    if(this.attendancedetails.attendance==="p"){
      this.marking="present";
    }
      
    });
  }
}
