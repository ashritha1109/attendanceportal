import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-pwdstud',
  templateUrl: './pwdstud.component.html',
  styleUrls: ['./pwdstud.component.css']
})
export class PwdstudComponent implements OnInit {
  current:any
    new:string=""
    singleStudentData:any

  constructor(private service:DataService) { }

  ngOnInit(): void {
    this.service.getStudentData().subscribe((data)=>{console.log(data)
      for(const i of data as any){
        if(i?.name===localStorage.getItem("username")&&i?.college===localStorage.getItem("college_name")){
          this.singleStudentData=i;
          break;
        }
      }
      console.log(this.singleStudentData)
    })
  }
onSubmit(currentpwd:string,newpwd:string){
console.log(currentpwd);
this.current=currentpwd;
this.new=newpwd;
this.singleStudentData.password=newpwd;
console.log(this.singleStudentData);
this.service.updateStudentPassword(this.singleStudentData).subscribe((data)=>{console.log(data)
alert("changed")
})
}

}
