import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PwdstudComponent } from './pwdstud.component';

describe('PwdstudComponent', () => {
  let component: PwdstudComponent;
  let fixture: ComponentFixture<PwdstudComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PwdstudComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PwdstudComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
