import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import {Urls} from '../../utilities/urls'
@Injectable({
  providedIn: 'root',
})
//Urls.teacherUrl.toString()
export class DataService {
  // url:string="https://localhost:44308/dbapp/v1/student";
url: string = 'https://localhost:44308/dbapp/v1/registercollege';
baseurl:string="https://localhost:44308/attendance/v1/teacher"
atturl:string="https://localhost:44308/attendance/v1/attendancedetails"
  constructor(private router: Router, private http: HttpClient) {}
  // sending registered data to sql db
  postRegisterData(data: any): Observable<any> {
    return this.http.post(this.url, JSON.stringify(data), {
      headers: { 'content-type': 'application/json' },
    });
  }
  // getting all registered colleges from DB
  getRegisteredData():Observable<any>{
    return this.http.get(this.url);
  }

  //getting all teachers
  getTeacherData():Observable<any>{
    return this.http.get(Urls.teacherUrl.toString());
  }
  getSingleTeacherData(id:any):Observable<any>{
    console.log( `${Urls.teacherUrl}${id}`)
    return this.http.get(`${Urls.teacherUrl}${id}`)
  }

  postTeacherData(data:any):Observable<any>{
    return this.http.post(Urls.teacherUrl.toString(),JSON.stringify(data),{
      headers: { 'content-type': 'application/json' },
    })
  }

  updateTeacherPassword(data:any):Observable<any>{
    return this.http.put(Urls.teacherUrl.toString(),JSON.stringify(data),{
      headers: { 'content-type': 'application/json' },
    })
  }

  // students
  postStudentData(data:any):Observable<any>{
    return this.http.post(Urls.studentUrl.toString(),JSON.stringify(data),{
      headers: { 'content-type': 'application/json' },
    })
  }

  getStudentData():Observable<any>{
    return this.http.get(Urls.studentUrl.toString())
  }

  getSingleStudent(id:any):Observable<any>{
    return this.http.get(`${Urls.studentUrl}${id}`);
  }

  updateStudentPassword(data:any):Observable<any>{
    return this.http.put(Urls.studentUrl.toString(),JSON.stringify(data),{
      headers: { 'content-type': 'application/json' },
    })
  }
// attendance

postAttendance(data:any):Observable<any>{
  return this.http.post(Urls.attendanceUrl.toString(),JSON.stringify(data),{
    headers: { 'content-type': 'application/json' },
  })
}
getAttendance():Observable<any>{
  return this.http.get(Urls.attendanceUrl.toString());
}
  // to check if user is logged in or not
  userLoginStatus(): boolean {
    if (localStorage.getItem('username') === null) {
      return false;
    } else {
      return true;
    }
  }
  onLogout() {
    localStorage.clear();
    this.router.navigate(['home']);
  }


  //admin
  
}
