import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-adminstudrepo',
  templateUrl: './adminstudrepo.component.html',
  styleUrls: ['./adminstudrepo.component.css']
})
export class AdminstudrepoComponent implements OnInit {
  attendancedetails: any;

  constructor(private service: DataService) { }

  ngOnInit(): void {
    
    this.service.getStudentData().subscribe((data) => {
      console.log(data);
      
      this.attendancedetails=data;
       
     });
  }

}
