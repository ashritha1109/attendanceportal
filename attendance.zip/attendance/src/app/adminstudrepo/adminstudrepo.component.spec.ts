import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminstudrepoComponent } from './adminstudrepo.component';

describe('AdminstudrepoComponent', () => {
  let component: AdminstudrepoComponent;
  let fixture: ComponentFixture<AdminstudrepoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdminstudrepoComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AdminstudrepoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
