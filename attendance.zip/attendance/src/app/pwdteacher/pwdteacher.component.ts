import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-pwdteacher',
  templateUrl: './pwdteacher.component.html',
  styleUrls: ['./pwdteacher.component.css']
})
export class PwdteacherComponent implements OnInit {
  current:any
  new:string=""
  singleTeacherData:any
  constructor(private service:DataService) { }

  ngOnInit(): void {
    this.service.getTeacherData().subscribe((data)=>{
      console.log(data);
      for(const i of data as any){
        if(i?.name===localStorage.getItem("username")&&i?.college_name===localStorage.getItem("college_name")){
          this.singleTeacherData=i;
          break;
        }
      }

    })
  }
onSubmit(currentpwd:string,newpwd:string){
console.log(currentpwd);
this.current=currentpwd;
this.new=newpwd;
this.singleTeacherData.password=newpwd;
console.log(this.singleTeacherData);
this.service.updateTeacherPassword(this.singleTeacherData).subscribe((data)=>{console.log(data)
alert("changed")
})
}
}
