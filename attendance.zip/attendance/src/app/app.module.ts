import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { ReactiveFormsModule , FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { RegisterComponent } from './components/register/register.component';
import { LoginComponent } from './components/login/login.component';
import { ContactusComponent } from './components/contactus/contactus.component';
import { StudentComponent } from './components/student/student.component';
import { AdminComponent } from './components/admin/admin.component';
import { TeacherComponent } from './components/teacher/teacher.component';
import { StudentreportComponent } from './components/studentreport/studentreport.component';
import { TeacherhomeComponent } from './components/teacherhome/teacherhome.component';
import { AdminhomeComponent } from './components/adminhome/adminhome.component';
import { ViewcollegeComponent } from './components/viewcollege/viewcollege.component';
import { AddcollegeComponent } from './components/addcollege/addcollege.component';
import { StudenthomeComponent } from './components/studenthome/studenthome.component';

import { MarkattendanceComponent } from './components/markattendance/markattendance.component';
import { StudprofileComponent } from './components/studprofile/studprofile.component';
import {HttpClientModule} from '@angular/common/http';
import { CreateclassComponent } from './components/createclass/createclass.component';
import { CreatestudentComponent } from './components/createstudent/createstudent.component';
import { UpdatecollegeComponent } from './components/updatecollege/updatecollege.component';
import { MatDialogModule} from '@angular/material/dialog';

import {MatFormFieldModule} from '@angular/material/form-field';
import { MatTableModule } from '@angular/material/table' ;



import { MatDatepickerModule } from '@angular/material/datepicker';

import { MatNativeDateModule } from '@angular/material/core';

import {MatInputModule} from '@angular/material/input';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {NgxPaginationModule} from 'ngx-pagination';
import {MatPaginator, MatPaginatorModule} from '@angular/material/paginator';

import { CreatefacultyComponent } from './components/createfaculty/createfaculty.component';
import { CollegeadminComponent } from './collegeadmin/collegeadmin.component'
import { FlexLayoutModule } from '@angular/flex-layout';
import { PwdstudComponent } from './pwdstud/pwdstud.component';
import { AttendancerepoComponent } from './attendancerepo/attendancerepo.component';
import { PwdteacherComponent } from './pwdteacher/pwdteacher.component';
import { AdminstudrepoComponent } from './adminstudrepo/adminstudrepo.component'

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    RegisterComponent,
    LoginComponent,
    ContactusComponent,
    StudentComponent,
    AdminComponent,
    TeacherComponent,
    StudentreportComponent,
    TeacherhomeComponent,
    AdminhomeComponent,
    ViewcollegeComponent,
    AddcollegeComponent,
    StudenthomeComponent,
  
    MarkattendanceComponent,
    StudprofileComponent,
    CreateclassComponent,
    CreatestudentComponent,
    UpdatecollegeComponent,
    CreatefacultyComponent,
    CollegeadminComponent,
    PwdstudComponent,
    AttendancerepoComponent,
    PwdteacherComponent,
    AdminstudrepoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatDatepickerModule,
    MatFormFieldModule,
    MatInputModule,
    MatDialogModule,
    MatNativeDateModule,
    MatTableModule,
    BrowserAnimationsModule,
    NgxPaginationModule,
    MatPaginatorModule,
    FlexLayoutModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
