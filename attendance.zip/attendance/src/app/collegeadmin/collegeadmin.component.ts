import { Component, OnInit } from '@angular/core';
import { DataService } from '../services/data.service';

@Component({
  selector: 'app-collegeadmin',
  templateUrl: './collegeadmin.component.html',
  styleUrls: ['./collegeadmin.component.css']
})
export class CollegeadminComponent implements OnInit {

  constructor(public service:DataService) { }

  ngOnInit(): void {
  }

}
