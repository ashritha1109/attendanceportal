import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-studentreport',
  templateUrl: './studentreport.component.html',
  styleUrls: ['./studentreport.component.css']
})
export class StudentreportComponent implements OnInit {
  attendancedetails: any;
  marking:string="";
  teacher:any;
  constructor(private service: DataService) { }

  ngOnInit(): void {

    this.service.getStudentData().subscribe((data) => {
      console.log(data);
      
      this.attendancedetails=data;
       this.teacher=localStorage.getItem("username")
     });
  }

}
