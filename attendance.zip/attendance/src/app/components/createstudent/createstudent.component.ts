import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { DataService } from 'src/app/services/data.service';
@Component({
  selector: 'app-createstudent',
  templateUrl: './createstudent.component.html',
  styleUrls: ['./createstudent.component.css']
})
export class CreatestudentComponent implements OnInit {
  studentForm=new FormGroup({
    name:new FormControl(''),
    password:new FormControl(''),
    email:new FormControl(''),
    class:new FormControl(''),
    section:new FormControl(''),
    rollno:new FormControl(''),
    teacher:new FormControl(''),
    college:new FormControl('')
  })
  constructor(private service:DataService) { }

  ngOnInit(): void {
    this.service.getTeacherData().subscribe((data)=>{
      for(const i of data as any){
        if(i.name===localStorage.getItem("username") && i.college_name===localStorage.getItem("college_name"))
        {
          console.log(i);
          this.studentForm.controls.class.setValue(i.class);
          this.studentForm.controls.college.setValue(i.college_name);
          if(i.section==1){
            this.studentForm.controls.section.setValue("A");
          }
          else if(i.section==2){
            this.studentForm.controls.section.setValue("B");
          }
         else {
            this.studentForm.controls.section.setValue("C");
          }
          this.studentForm.controls.teacher.setValue(i.name)
        
        }
      }

    })
  }
  onSubmit(){
      this.service.postStudentData(this.studentForm.value).subscribe((data)=>{
        console.log(data);
        alert("added");
      },
      (err)=>{console.log(err);})
    
  }
}
