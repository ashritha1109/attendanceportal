import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ViewportScroller } from '@angular/common';
import { FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { DataService } from 'src/app/services/data.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  UserName: any;
  CollegeName:any;
  loginDetails = new FormGroup({
    name: new FormControl(''),
    password: new FormControl(''),
    college_name:new FormControl('')
  });
  role: string = '';
  constructor(
    private router: Router,
    private scroller: ViewportScroller,
    private service: DataService
  ) {}

  ngOnInit(): void {}

  goToLogin(event: any) {
    this.scroller.scrollToAnchor('login');
    console.log(event.target.value);
    this.role = event.target.value;
  }
  onLogin() {
    console.log(this.loginDetails.value.name);
    this.UserName = this.loginDetails.value.name;
    this.CollegeName=this.loginDetails.value.college_name;
    localStorage.setItem('username', this.UserName);
    localStorage.setItem('college_name',this.CollegeName)
    // IF ROLE===STUDENT
    if (this.role === 'student') {
      this.router.navigate(['student']);
    }
    // IF ROLE===ADMIN
    else if (this.role === 'admin') {
      this.router.navigate(['admin']);
    }
    else if(this.role==='teacher'){
      console.log("this is teacher")
      this.service.getTeacherData().subscribe((data)=>{
        console.log("login",data);
        let flag=0;
        for(const user of data as any){
          if(user.name===this.loginDetails.value.name){
            if(user.password===this.loginDetails.value.password){
              if(user.college_name===this.loginDetails.value.college_name){
                this.router.navigate(['teacher'])
                flag=1;
                break;
              }
        
            }
          }
          else{
            flag=0;
          }
        }
        if(flag===0){
          alert('invalid');
        }
      })
    
    }
    //IF ROLE===COLLEGE ADMIN
    else if (this.role === 'collegeadmin') {
      // getting all registered college admins details
      this.service.getRegisteredData().subscribe((data) => {
        console.log(data);
        let flag = 0; // for checking invalid credentials
        for (const user of data as any) {
          if (user.username === this.loginDetails.value.name) {
            if (user.pwd === this.loginDetails.value.password) {
              // navigating to teacher home page after successful login
              this.router.navigate(['collegeadmin']);
              flag = 1;
              break;
            }
          } else {
            // when either username or password is incorrect
            flag = 0;
          }
        }
        if (flag === 0) {
          alert('invalid');
        }
      });
    }
  }
}
