import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-updatecollege',
  templateUrl: './updatecollege.component.html',
  styleUrls: ['./updatecollege.component.css']
})
export class UpdatecollegeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
