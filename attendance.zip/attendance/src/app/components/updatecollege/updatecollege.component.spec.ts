import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdatecollegeComponent } from './updatecollege.component';

describe('UpdatecollegeComponent', () => {
  let component: UpdatecollegeComponent;
  let fixture: ComponentFixture<UpdatecollegeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UpdatecollegeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(UpdatecollegeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
