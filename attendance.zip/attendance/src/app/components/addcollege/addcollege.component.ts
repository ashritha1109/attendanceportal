import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-addcollege',
  templateUrl: './addcollege.component.html',
  styleUrls: ['./addcollege.component.css']
})
export class AddcollegeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
