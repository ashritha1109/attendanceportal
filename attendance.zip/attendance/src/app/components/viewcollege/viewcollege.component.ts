import {OnInit } from '@angular/core';
import { Data, Router } from '@angular/router';
import { DataService } from 'src/app/services/data.service';
import {MatPaginator} from '@angular/material/paginator';
import {AfterViewInit, Component, ViewChild} from '@angular/core';
import {MatTableDataSource} from '@angular/material/table';
const COLUMNS_SCHEMA = [
  {
    key: 'username',
    type: 'text',
    label: 'UserName',
  },
  {
    key: 'college_Name',
    type: 'text',
    label: 'College',
  },
  {
    key: 'email',
    type: 'text',
    label: 'Email',
  },

  {
    key: 'isEdit',
    type: 'isEdit',
    label: '',
  },
];
@Component({
  selector: 'app-viewcollege',
  templateUrl: './viewcollege.component.html',
  styleUrls: ['./viewcollege.component.css']
})
export class ViewcollegeComponent implements  AfterViewInit {
  registeredColleges:any;
  p:any;
  constructor(private router:Router,private service:DataService) { }
  @ViewChild(MatPaginator) paginator: any;
  ngOnInit(): void {
    this.service.getRegisteredData().subscribe((data)=>{console.log(data)
    this.registeredColleges=data;
    console.log(this.registeredColleges)}
    )
    
  }
  displayedColumns: string[] = COLUMNS_SCHEMA.map((col) => col.key);
  columnsSchema: any = COLUMNS_SCHEMA;
  EditingStarted(element:any){
    console.log(element)
  }
  EditingDone(element:any){
    console.log(element)
    let editedUser={
      username:element.username,
      college:element.college_Name,
      email:element.email
    }
    
  }
  ngAfterViewInit(): void {
    this.service.getRegisteredData().subscribe((data)=>{console.log(data)
      this.registeredColleges=data;
      console.log(this.registeredColleges)
      this.registeredColleges = new MatTableDataSource<any>(data);
  
    this.registeredColleges.paginator = this.paginator;}
      )
  
  }
  // editCollegeData(id:number){
  //   this.router.navigate(['updatecollege/'+id])
  // }
  // deleteCollegeData(id:number){

  // }
  
}
