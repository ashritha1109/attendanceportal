import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewcollegeComponent } from './viewcollege.component';

describe('ViewcollegeComponent', () => {
  let component: ViewcollegeComponent;
  let fixture: ComponentFixture<ViewcollegeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewcollegeComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewcollegeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
