import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudprofileComponent } from './studprofile.component';

describe('StudprofileComponent', () => {
  let component: StudprofileComponent;
  let fixture: ComponentFixture<StudprofileComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ StudprofileComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(StudprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
