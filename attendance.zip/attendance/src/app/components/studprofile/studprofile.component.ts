import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormControl } from '@angular/forms';
@Component({
  selector: 'app-studprofile',
  templateUrl: './studprofile.component.html',
  styleUrls: ['./studprofile.component.css']
})
export class StudprofileComponent implements OnInit {
  singleStudentData:any;
  studentForm=new FormGroup({
    name:new FormControl(''),
    password:new FormControl(''),
    email:new FormControl(''),
    class:new FormControl(''),
    section:new FormControl(''),
    rollno:new FormControl(''),
    teacher:new FormControl(''),
    college:new FormControl('')
  })
  constructor(private service:DataService) { }

  ngOnInit(): void {
    console.log("start")
    this.service.getStudentData().subscribe((data)=>{
      console.log(data);
      for(const i of data as any){
        if(i?.name===localStorage.getItem("username")&&i?.college===localStorage.getItem("college_name")){
          this.singleStudentData=i;
          break;
        }
      }
      this.studentForm.controls.name.setValue(this.singleStudentData.name)
      this.studentForm.controls.password.setValue(this.singleStudentData.password)
      this.studentForm.controls.email.setValue(this.singleStudentData.email)
      this.studentForm.controls.teacher.setValue(this.singleStudentData.teacher)
      this.studentForm.controls.class.setValue(this.singleStudentData.class)
      this.studentForm.controls.section.setValue(this.singleStudentData.section)
      this.studentForm.controls.rollno.setValue(this.singleStudentData.rollno)

      console.log(this.singleStudentData)
    })
  }

}
