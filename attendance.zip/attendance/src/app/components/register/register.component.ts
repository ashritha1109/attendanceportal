import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { DataService } from 'src/app/services/data.service';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerDetails=new FormGroup({
    college_name:new FormControl(''),
    username:new FormControl(''),
    pwd:new FormControl(''),
    email:new FormControl('')
  })
  constructor(private router:Router,private service:DataService) { }

  ngOnInit(): void {
  }
  onRegister(){
    this.service.postRegisterData(this.registerDetails.value).subscribe((data)=>{console.log(data); alert("added")},
    (err)=>{console.log(err);

    })
  }
}
