import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-teacherhome',
  templateUrl: './teacherhome.component.html',
  styleUrls: ['./teacherhome.component.css']
})
export class TeacherhomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
