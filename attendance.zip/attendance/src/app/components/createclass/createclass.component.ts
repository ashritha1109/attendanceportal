import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-createclass',
  templateUrl: './createclass.component.html',
  styleUrls: ['./createclass.component.css']
})
export class CreateclassComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
