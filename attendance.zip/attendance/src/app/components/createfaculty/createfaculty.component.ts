import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-createfaculty',
  templateUrl: './createfaculty.component.html',
  styleUrls: ['./createfaculty.component.css'],
})
export class CreatefacultyComponent implements OnInit {
  registrationForm = this.fb.group({
    name: ['', [Validators.required, Validators.minLength(5)]],
    password: ['', [Validators.required]],
    email: ['', [Validators.required, Validators.email]],
    class: ['', [Validators.required]],
    section: [''],
    college_name:['']
  });
event1:any;
event2:any;
  isSubmitted = false;

  Class: any = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X'];
  Section: any = ['A', 'B', 'C'];
  constructor(private service: DataService, public fb: FormBuilder) {}
  ngOnInit(): void {}
  changeClass(event: any) {
    this.class?.setValue(event.target.value);
   this.event1=event
  }
  changeSection(event: any) {
    this.section?.setValue(event.target.value);
   this.event2=event;
  }
  get class() {
    return this.registrationForm.get('class');
    
  }
  get section() {
    return this.registrationForm.get('section');
  }

  onSubmit() {
    this.isSubmitted = true;
    console.log(this.event1.target.value)
    console.log(this.registrationForm);
    this.registrationForm.value.class=this.event1.target.value[0];
    this.registrationForm.value.section=this.event2.target.value[0];
    this.registrationForm.value.college_name=localStorage.getItem("college_name");
    
    this.service.postTeacherData(this.registrationForm.value).subscribe((data)=>{console.log(data),
    alert("added")});
    if (!this.registrationForm.valid) {
      return false;
    } else {
      //alert(JSON.stringify(this.registrationForm.value));
    }
    return false;
  }
  
}
