import { Time } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';
@Component({
  selector: 'app-markattendance',
  templateUrl: './markattendance.component.html',
  styleUrls: ['./markattendance.component.css'],
})
export class MarkattendanceComponent implements OnInit {
  studentDetails: any;
  attendanceCount = 0;
  attendanceDetails: any = {
    rollno: Number,
    uname: String,

    email: String,
    college: String,
    teacher: String,
    class: String,
    section: String,
    attendance: String,
    timemark: Number,
    date: String,
  };
  constructor(private service: DataService) {}
  currentDate: any = new Date();
  timestamp: any = this.currentDate.getTime();
  currdate: any = this.currentDate.toLocaleDateString();
  ngOnInit(): void {
    this.service.getStudentData().subscribe((data) => {

      this.studentDetails = data;
    });
  }

  onPresent(event: any, roll: any, name: any) {
    this.service.getStudentData().subscribe((data) => {
      this.attendanceCount = this.attendanceCount + 1;
      //console.log(data);
      this.studentDetails = data;
      for (const i of data) {
        if (i.rollno === roll) {
          console.log(i);

          this.attendanceDetails.rollno = i.rollno;
          this.attendanceDetails.uname = name;
          this.attendanceDetails.email = i.email;
          this.attendanceDetails.college = i.college;
          this.attendanceDetails.teacher = i.teacher;
          this.attendanceDetails.class = i.class;
          this.attendanceDetails.section = i.section;
          this.attendanceDetails.attendance = event;
          this.attendanceDetails.timemark = this.timestamp;
          this.attendanceDetails.date = this.currdate;
        }
      }
      this.service.postAttendance(this.attendanceDetails).subscribe((data) => {
        console.log(data);
        alert('added');
      });
    });

    console.log(this.attendanceDetails);
  }
  onAbsent(event: any, roll: any, name: any) {
    this.service.getStudentData().subscribe((data) => {
      //console.log(data);
      this.studentDetails = data;
      for (const i of data) {
        if (i.rollno === roll) {
          console.log(i);

          this.attendanceDetails.rollno = i.rollno;
          this.attendanceDetails.uname = name;
          this.attendanceDetails.email = i.email;
          this.attendanceDetails.college = i.college;
          this.attendanceDetails.teacher = i.teacher;
          this.attendanceDetails.class = i.class;
          this.attendanceDetails.section = i.section;
          this.attendanceDetails.attendance = event;
          this.attendanceDetails.timemark = this.timestamp;
          this.attendanceDetails.date = this.currdate;
        }
      }
      this.service.postAttendance(this.attendanceDetails).subscribe((data) => {
        console.log(data);
        alert('added');
      });
    });
    console.log(this.attendanceDetails);
  }
}
