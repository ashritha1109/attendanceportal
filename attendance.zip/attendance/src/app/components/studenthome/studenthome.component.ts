import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/data.service';

@Component({
  selector: 'app-studenthome',
  templateUrl: './studenthome.component.html',
  styleUrls: ['./studenthome.component.css']
})
export class StudenthomeComponent implements OnInit {
  currentDate: any = new Date();
  timestamp: any = this.currentDate.getTime();
  currdate: any = this.currentDate.toLocaleDateString();
  attendancedetails: any;
  constructor(public service:DataService) { }

  ngOnInit(): void {
    this.service.getAttendance().subscribe((data) => {
      // console.log(data);
      for(const i of data as any){
        var username=localStorage.getItem("username");
        if(i.uname===username){
          this.attendancedetails=i;
          break;
          
        }
      }
      console.log(this.attendancedetails)     

     });
  }

}
