import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdminstudrepoComponent } from './adminstudrepo/adminstudrepo.component';
import { AttendancerepoComponent } from './attendancerepo/attendancerepo.component';
import { CollegeadminComponent } from './collegeadmin/collegeadmin.component';
import { AddcollegeComponent } from './components/addcollege/addcollege.component';
import { AdminComponent } from './components/admin/admin.component';
import { AdminhomeComponent } from './components/adminhome/adminhome.component';
import { ContactusComponent } from './components/contactus/contactus.component';
import { CreateclassComponent } from './components/createclass/createclass.component';
import { CreatefacultyComponent } from './components/createfaculty/createfaculty.component';
import { CreatestudentComponent } from './components/createstudent/createstudent.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { MarkattendanceComponent } from './components/markattendance/markattendance.component';
import { RegisterComponent } from './components/register/register.component';
import { StudentComponent } from './components/student/student.component';
import { StudenthomeComponent } from './components/studenthome/studenthome.component';
import { StudentreportComponent } from './components/studentreport/studentreport.component';
import { StudprofileComponent } from './components/studprofile/studprofile.component';
import { TeacherComponent } from './components/teacher/teacher.component';
import { TeacherhomeComponent } from './components/teacherhome/teacherhome.component';
import { UpdatecollegeComponent } from './components/updatecollege/updatecollege.component';
import { ViewcollegeComponent } from './components/viewcollege/viewcollege.component';
import { LoginGuard } from './login.guard';
import { PwdstudComponent } from './pwdstud/pwdstud.component';
import { PwdteacherComponent } from './pwdteacher/pwdteacher.component';

const routes: Routes = [
  { path: 'home', component: HomeComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'contactus', component: ContactusComponent },
  {
    path: 'student',
    component: StudentComponent,
    canActivate:[LoginGuard],
    children: [
      { path: 'studprofile', component: StudprofileComponent ,canActivate:[LoginGuard]},
      { path: 'studenthome', component: StudenthomeComponent ,canActivate:[LoginGuard]},
      {path:'pwdstud',component:PwdstudComponent ,canActivate:[LoginGuard]}
    ],
  },
  {
    path: 'admin',
    canActivate:[LoginGuard],
    component: AdminComponent,

    children: [
      { path: 'adminhome', component: AdminhomeComponent ,canActivate:[LoginGuard]},
      { path: 'viewcollege', component: ViewcollegeComponent ,canActivate:[LoginGuard]},
      { path: 'addcollege', component: AddcollegeComponent ,canActivate:[LoginGuard]},
      { path: 'updatecollege', component: UpdatecollegeComponent ,canActivate:[LoginGuard]},
    ],

  },
  {
    path: 'teacher',
    component: TeacherComponent,
    children: [
      { path: 'studentreport', component: StudentreportComponent   ,  canActivate:[LoginGuard]},
      { path: 'teacherhome', component: TeacherhomeComponent  ,  canActivate:[LoginGuard]},
      { path: 'markattendance', component: MarkattendanceComponent  ,  canActivate:[LoginGuard]},
      { path: 'createstudent', component: CreatestudentComponent  ,  canActivate:[LoginGuard]},
      {path:'attendancerepo',component:AttendancerepoComponent  ,  canActivate:[LoginGuard]},
      {path:'pwdteacher',component:PwdteacherComponent  ,  canActivate:[LoginGuard]}
    ],
  },
  {
    path: 'collegeadmin',
    component: CollegeadminComponent,
    children: [
      { path: 'adminstudrepo', component: AdminstudrepoComponent },

      { path: 'createfaculty', component: CreatefacultyComponent },
    ],
  },
  { path: '**', redirectTo: '/home', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
