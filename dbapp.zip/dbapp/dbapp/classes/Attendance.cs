﻿using System;
using System.Numerics;

namespace dbapp.classes
{
    public class AttendanceDetails
    {
    
        public string Uname { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string Teacher { get; set; }
        public string Class { get; set; }
        public string Section { get; set; }
        public int Rollno { get; set; }

        public string College { get; set; }

        public string Attendance { get; set; }

        public long Timemark { get; set; }

        public string Date { get; set; } 


    }
}
