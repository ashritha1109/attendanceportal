﻿namespace dbapp.classes
{
    public class StudentDetails
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string Teacher { get; set; }
        public string Class { get; set; }
        public string Section { get; set; }
        public int Rollno { get; set; }

        public string College { get; set; }
    }
}
