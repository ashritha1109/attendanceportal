﻿namespace dbapp.Controllers
{
    public class Class
    {
    }
}
