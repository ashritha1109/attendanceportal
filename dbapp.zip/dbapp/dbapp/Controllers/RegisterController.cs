﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data.SqlClient;
using System;
using System.Globalization;
using static dbapp.Controllers.RegisterController;

namespace dbapp.Controllers
{
    [ApiController]
    [Route("dbapp/v1/registercollege")]
    public class RegisterController : ControllerBase
    {
        public class College
        {
            public int Id { get; set; }
            public string College_Name { get; set; }
            public string Username { get; set; }
            public string Pwd { get; set; }    

            public string Email { get; set; }
        }

       

        // POST: RegisterController/Edit/5
        [HttpPost]
        
        public List<College> postAll(College clg)
        {
            try
            {


                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48905\\SQLEXPRESS01;Database=registerdcolleges;Integrated Security=false;User Id=sa;Password=guvi;");
          

                connection.Open();

                //   string query = "insert into dbo.colleges (college_name,email,username,pwd) values('" + clg.College_Name + @"','" + clg.Email + @"','" + clg.Username + @"','" +clg.Pwd+ @"')";
              //  string query = "INSERT INTO [dbo].[colleges]([college_name],[username],[pwd],[email])VALUES('@collge_name','email','@username','password')";
              string query= $"INSERT INTO [dbo].[colleges]([college_name],[username],[pwd],[email])VALUES('{clg.College_Name}','{clg.Username}','{clg.Pwd}','{clg.Email}')";
                SqlCommand cmd = new SqlCommand(query, connection);
                //cmd.Parameters.AddWithValue("@college_name", clg.College_Name);
                //cmd.Parameters.AddWithValue("@email", clg.Email);
                //cmd.Parameters.AddWithValue("@username", clg.Username);
                //cmd.Parameters.AddWithValue("@password",clg.Pwd);
                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {

                    List<College> colleges = new List<College>();

                    College college = null;
                    while (a.Read())
                    {
                        college = new College();
                        college.Id = Convert.ToInt32(a["id"]);
                        college.Username = a["college_name"].ToString();
                        college.Pwd = a["pwd"].ToString();
                        college.Email = a["email"].ToString();
                        college.Username = a["username"].ToString();

                        colleges.Add(college);
                    }
                    return colleges;
                }
            }
               
            catch (Exception)
            {

                throw;
            }



            return null;
        }

        [HttpGet]
        public List<College> GetColleges()
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48905\\SQLEXPRESS01;Database=registerdcolleges;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = "select * from dbo.colleges";

                SqlCommand cmd= new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {
                    List<College> colleges = new List<College>();

                    College college = null;
                    while (a.Read())
                    {
                        college = new College();
                        college.Id = Convert.ToInt32(a["id"]);
                        college.College_Name = a["college_name"].ToString();
                        college.Pwd = a["pwd"].ToString();
                        college.Email = a["email"].ToString();
                        college.Username = a["username"].ToString();

                        colleges.Add(college);
                    }
                    return colleges;
                }
               
            }

            catch(Exception e)
            {
                throw e;
            }
            return null;
        }

        [HttpGet("{id}")]
        public ActionResult<College> GetSingleCollege(int id)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48905\\SQLEXPRESS01;Database=registerdcolleges;Integrated Security=false;User Id=sa;Password=guvi;");

                connection.Open();

                string query = $"select * from dbo.colleges where id={id}";

                SqlCommand cmd = new SqlCommand(query, connection);

                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {
                    List<College> colleges = new List<College>();

                    College college = null;
                    if (a.Read())
                    {
                        college = new College();
                        college.Id = Convert.ToInt32(a["id"]);
                        college.College_Name = a["college_name"].ToString();
                        college.Pwd = a["pwd"].ToString();
                        college.Email = a["email"].ToString();
                        college.Username = a["username"].ToString();

                        //    colleges.Add(college);
                        
                    }
                    return college;
                }

            }

            catch (Exception e)
            {
                throw e;
            }
            return NoContent();
        }

    }

}



