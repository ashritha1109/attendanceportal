﻿using dbapp.classes;
using dbapp.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Data.SqlClient;
using System;
using MongoDB.Driver;

namespace dbapp.Controllers
{
    [ApiController]
    [Route("attendance/v1/attendancedetails")]
    public class AttendanceController : ControllerBase
    {
        [HttpGet]

        public ActionResult<List<AttendanceDetails>> GetStudents()
        {
            try
            {
                using (var con = Connection.GetAttendanceConnection())
                {
                    //SqlConnection con = new SqlConnection("server=apinp-elpt48905\\sqlexpress01;database=students;integrated security=false;user id=sa;password=guvi;");
                    con.Open();
                    string query = "select * from attendance";

                    SqlCommand cmd = new SqlCommand(query, con);
                    var row = cmd.ExecuteReader();
                    if (row.HasRows)
                    {
                        List<AttendanceDetails> students = new List<AttendanceDetails>();
                        AttendanceDetails student = null;
                        while (row.Read())
                        {
                            student = new AttendanceDetails();


                            student.Uname = row["uname"].ToString();
                            student.Email = row["email"].ToString();
                            student.Class = row["class"].ToString();
                            student.Section = row["section"].ToString();
                            student.College = row["college"].ToString();
                            student.Rollno = Convert.ToInt32(row["rollno"]);
                            student.Teacher = row["teacher"].ToString();
                            student.Date = row["date"].ToString();
                            student.Timemark = Convert.ToInt64(row["timemark"]);
                            student.Attendance = row["attendance"].ToString();
                            students.Add(student);
                        }
                        return Ok(students);
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return NoContent();
        }

        [HttpPost]

        public IActionResult InsertStudents(AttendanceDetails student)
        {
            try

            {
               // SqlConnection con = new SqlConnection("server=apinp-elpt48905\\sqlexpress01;database=students;integrated security=false;user id=sa;password=guvi;");
                using (var con = Connection.GetAttendanceConnection())
                {
                    con.Open();
                string query = "INSERT INTO [dbo].[attendance]([rollno],[uname],[email],[college],[teacher],[class],[section] ,[attendance] ,[timemark] ,[date])VALUES (@rollno,@uname,@email,@college,@teacher,@class,@section,@attendance,@timemark,@date)";
                SqlCommand cmd = new SqlCommand(query, con);
            
               
                        cmd.Parameters.AddWithValue("@uname", student.Uname);
                    
               
                  
                        cmd.Parameters.AddWithValue("@email", student.Email);
                    
                    cmd.Parameters.AddWithValue("@college", student.College);
                cmd.Parameters.AddWithValue("@teacher", student.Teacher);
                cmd.Parameters.AddWithValue("@class", student.Class);
                cmd.Parameters.AddWithValue("@section", student.Section);
                cmd.Parameters.AddWithValue("@rollno", student.Rollno);
                    cmd.Parameters.AddWithValue("@attendance", student.Attendance);
                    cmd.Parameters.AddWithValue("@timemark", student.Timemark);
                    cmd.Parameters.AddWithValue("@date", student.Date);

                if (cmd.ExecuteNonQuery() == 1)
                {
                    return Ok();
                }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Ok();
        }
    }
}
