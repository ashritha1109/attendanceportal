﻿using dbapp.classes;
using dbapp.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace dbapp.Controllers
{
    [ApiController]
    [Route("attendance/v1/teacher")]
    public class CreateTeacherController : ControllerBase
    {
        [HttpGet]
        public ActionResult<List<Teacher>> GetTeachers()
        {
            try
            {
              

                using (var con = Connection.GetConnection())
                {
                    con.Open();
                    string query = "select * from teacher";

                    SqlCommand cmd = new SqlCommand(query, con);
                    var row = cmd.ExecuteReader();
                    if (row.HasRows)
                    {
                        List<Teacher> teachers = new List<Teacher>();
                        Teacher teacher = null;
                        while (row.Read())
                        {
                            teacher = new Teacher();
                            teacher.Id = Convert.ToInt32(row["id"]);
                            teacher.Name = row["name"].ToString();
                            teacher.Password = row["password"].ToString();
                            teacher.Email = row["email"].ToString();
                            teacher.Class = row["class"].ToString();
                            teacher.Section = row["section"].ToString();

                            teacher.College_name = row["college_name"].ToString();
                            teacher.Att_count = Convert.ToInt32(row["att_count"]);
                            teachers.Add(teacher);
                        }
                        con.Close();
                        return Ok(teachers);
                    }
                    
                }
            }
            catch (Exception) { throw; }
            // catch(Exception ex) {
            //  return InternalSErverError( new CusomtError() { status: 500, errromessage: ex.tostring() })
            // }
            return NoContent();

        }

        [HttpPost]

        public IActionResult InsertTeacher(Teacher teacher)
        {
            try
            {

                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48905\\SQLEXPRESS01;Database=teachers;Integrated Security=false;User Id=sa;Password=guvi;");
                connection.Open();
                string query = "INSERT INTO [dbo].[teacher]([name],[password],[email],[class],[section],[college_name],[att_count])VALUES(@name,@password,@email,@class,@section,@college_name,@att_count)";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@name", teacher.Name);
                cmd.Parameters.AddWithValue("@password", teacher.Password);
                cmd.Parameters.AddWithValue("@email", teacher.Email);
                cmd.Parameters.AddWithValue("@class", teacher.Class);
                cmd.Parameters.AddWithValue("@section", teacher.Section);
                cmd.Parameters.AddWithValue("@college_name", teacher.College_name);
                cmd.Parameters.AddWithValue("@att_count", teacher.Att_count);

                if (cmd.ExecuteNonQuery() == 1)
                {
                    return Ok();
                }

            }
            catch (Exception)
            {
                throw;
            }
            return null;
        }
        [HttpGet("{id}")]
        public ActionResult<Teacher> GetSingleTeacher(string id)
        {
            try
            {
                SqlConnection con = new SqlConnection("server=apinp-elpt48905\\sqlexpress01;database=teachers;integrated security=false;user id=sa;password=guvi;");
                //sqlconnection connection = new sqlconnection(connectionstring);
                con.Open();
            string query = $"select * from dbo.teacher where id={id}";

                SqlCommand cmd = new SqlCommand(query, con);
            var row = cmd.ExecuteReader();
            if (row.HasRows)
            {
                List<Teacher> teachers = new List<Teacher>();
                Teacher teacher = null;
                while (row.Read())
                {
                    teacher = new Teacher();
                    teacher.Id = Convert.ToInt32(row["id"]);
                    teacher.Name = row["name"].ToString();
                    teacher.Password = row["password"].ToString();
                    teacher.Email = row["email"].ToString();
                    teacher.Class = row["class"].ToString();
                    teacher.Section = row["section"].ToString();

                    teacher.College_name = row["college_name"].ToString();
                    //teachers.Add(teacher);
                }
                    return teacher;
                }
                

            }
            catch (Exception) { throw; }
            // catch(Exception ex) {
            //  return InternalSErverError( new CusomtError() { status: 500, errromessage: ex.tostring() })
            // }
            return NoContent();

}
        [HttpPut]
        public ActionResult<Teacher> UpdatePassword(Teacher teacher)
        {
            try
            {
                SqlConnection con = new SqlConnection("server=apinp-elpt48905\\sqlexpress01;database=teachers;integrated security=false;user id=sa;password=guvi;");
               
                con.Open();
                string query = $"UPDATE [dbo].[teacher] SET [password] = '{teacher.Password}' WHERE id='{teacher.Id}'";

                SqlCommand cmd = new SqlCommand(query, con);
                var row = cmd.ExecuteReader();
                if (row.HasRows)
                {
                   
                    if (row.Read())
                    {
                        return teacher;
                    }

                }


            }
            catch (Exception) { throw; }
            // catch(Exception ex) {
            //  return InternalSErverError( new CusomtError() { status: 500, errromessage: ex.tostring() })
            // }
            return NoContent();
        }

    }


}
