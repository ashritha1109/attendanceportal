﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Security;
using System.Threading.Tasks;
using static dbapp.Controllers.RegisterController;

namespace dbapp.Controllers
{   public class StudentDeets
    {
        public int Sid { get; set; }
        public string Name { get; set; }
        public string Pwd { get; set; }

        public string Dept { get; set; }

        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        
        public string _id { get; set; }


    }
    public class Student
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
    }
    public class College
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public string Email { get; set; }
    }

    [ApiController]
    [Route("dbapp/v1/student")]
    public class WeatherForecastController : ControllerBase
    {

        // SqlConnection sq = new SqlConnection();
        [HttpGet]
        public  List<Student> GetAll()

        {

            try
            {


                SqlConnection connection = new SqlConnection("server=apinp-elpt48905\\sqlexpress01;database=learning;integrated security=false;user id=sa;password=guvi;");
                //sqlconnection connection = new sqlconnection(connectionstring);

                connection.Open();
                string query = "select * from student";

                SqlCommand cmd = new SqlCommand(query, connection);
                var a = cmd.ExecuteReader();
                if (a.HasRows)
                {
                    List<Student> students = new List<Student>();
                    Student student = null;
                    while (a.Read())
                    {
                        student = new Student();
                        student.ID = Convert.ToInt32(a["id"]);
                        student.Name = a["name"].ToString();
                        student.Password = a["dept"].ToString();

                        students.Add(student);
                    }
                    return students;
                }
    

            }
            catch (Exception)
            {

                throw;
            }



            return null;



        }
        [HttpPost]
        //public List<Student> postAll(Student stud)
        //{
        //    try
        //    {


        //        SqlConnection connection = new SqlConnection("Server=APINP-ELPT48905\\SQLEXPRESS01;Database=learning;Integrated Security=false;User Id=sa;Password=guvi;");
        //        //SqlConnection connection = new SqlConnection(connectionString);

        //        connection.Open();
        //        //string query = "insert into dbo.student values('ben','civil')";
        //        string query="insert into dbo.student (name,dept) values('"+ stud.Name + @"','"+ stud.Dept + @"')";

        //        SqlCommand cmd = new SqlCommand(query, connection);
        //        var a = cmd.ExecuteReader();
        //        if (a.HasRows)
        //        {
        //            List<Student> students = new List<Student>();
        //            Student student = null;
        //            while (a.Read())
        //            {
        //                student = new Student();
        //                student.ID = Convert.ToInt32(a["id"]);
        //                student.Name = a["name"].ToString();
        //                student.Dept = a["dept"].ToString();

        //                students.Add(student);
        //            }
        //            return students;
        //        }
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }



        //    return null;
        //}
        public IActionResult postAll(Student stud)
        {
            try
            {


                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48905\\SQLEXPRESS01;Database=studdetails;Integrated Security=false;User Id=sa;Password=guvi;");
                //SqlConnection connection = new SqlConnection(connectionString);
               
                connection.Open();

                   string query = "INSERT INTO [dbo].[studentDetails]([name],[password])VALUES(@name,@dept)";

              

                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@name", stud.Name);
                cmd.Parameters.AddWithValue("@dept", stud.Password);
                //  var a = cmd.ExecuteReader();
                if (cmd.ExecuteNonQuery()==1)
                {
                    return Ok("student added");
                }
            }
            catch (Exception)
            {

                throw;
            }



            return UnprocessableEntity();
        }



        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {

            try {
                SqlConnection connection = new SqlConnection("Server=APINP-ELPT48905\\SQLEXPRESS01;Database=learning;Integrated Security=false;User Id=sa;Password=guvi;");
                //SqlConnection connection = new SqlConnection(connectionString);

                connection.Open();
               // string query = "select * from student";

                SqlCommand cmd = new SqlCommand("deleteStudent", connection);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@id", id);

                if (cmd.ExecuteNonQuery() == 1)
                {
                    return Ok("student deleted");
                }
                
            }
            catch(SqlException) { }
            return UnprocessableEntity();
        }
    }
}