﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using dbapp.classes;
using dbapp.Repository;
using System;
using System.Data.SqlClient;

namespace dbapp.Controllers
{
    [ApiController]
    [Route("attendance/v1/student")]
    public class StudentController : ControllerBase
    {
        [HttpGet]

        public ActionResult<List<StudentDetails>> GetStudents()
        {
            try
            {
                using (var con = Connection.GetStudentConnection())
                {
                    //SqlConnection con = new SqlConnection("server=apinp-elpt48905\\sqlexpress01;database=students;integrated security=false;user id=sa;password=guvi;");
                    con.Open();
                string query = "select * from student_details";

                SqlCommand cmd = new SqlCommand(query, con);
                var row = cmd.ExecuteReader();
                if (row.HasRows)
                {
                    List<StudentDetails> students = new List<StudentDetails>();
                    StudentDetails student = null;
                    while (row.Read())
                    {
                        student = new StudentDetails();

                    
                        student.Name = row["name"].ToString();
                        student.Password = row["password"].ToString();
                        student.Email = row["email"].ToString();
                        student.Class = row["class"].ToString();
                        student.Section = row["section"].ToString();
                        student.College = row["college"].ToString();
                        student.Rollno = Convert.ToInt32(row["rollno"]);
                        student.Teacher = row["teacher"].ToString();
                        students.Add(student);
                    }
                    return Ok(students);
                }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return NoContent();
        }

        [HttpPost]

        public IActionResult InsertStudents(StudentDetails student)
        {
            try

            {
                SqlConnection con = new SqlConnection("server=apinp-elpt48905\\sqlexpress01;database=students;integrated security=false;user id=sa;password=guvi;");
                //using (var con = Connection.GetStudentConnection())
                //{
                con.Open();
                string query = "INSERT INTO [dbo].[student_details] ([name],[password],[email],[college],[teacher],[class],[section],[rollno])VALUES(@name,@password,@email,@college,@teacher,@class,@section,@rollno)";
                SqlCommand cmd = new SqlCommand(query, con);
                cmd.Parameters.AddWithValue("@name", student.Name);
                cmd.Parameters.AddWithValue("@password", student.Password);
                cmd.Parameters.AddWithValue("@email", student.Email);
                cmd.Parameters.AddWithValue("@college", student.College);
                cmd.Parameters.AddWithValue("@teacher", student.Teacher);
                cmd.Parameters.AddWithValue("@class", student.Class);
                cmd.Parameters.AddWithValue("@section", student.Section);
                cmd.Parameters.AddWithValue("@rollno", student.Rollno);

                if (cmd.ExecuteNonQuery() == 1)
                {
                    return Ok();
                }
                //}
            }
            catch (Exception)
            {
                throw;
            }
            return NoContent();
        }

        [HttpGet("{rollno}")]
        public ActionResult<StudentDetails> GetSingleStudent(int rollno)
        {
            try
            {
                SqlConnection con = new SqlConnection("server=apinp-elpt48905\\sqlexpress01;database=students;integrated security=false;user id=sa;password=guvi;");
            
                con.Open();
                string query = $"select * from dbo.student_details where rollno={rollno}";

                SqlCommand cmd = new SqlCommand(query, con);
                var row = cmd.ExecuteReader();
                if (row.HasRows)
                {
                    List<StudentDetails> students = new List<StudentDetails>();
                    StudentDetails student = null;
                    while (row.Read())
                    {
                        student = new StudentDetails();
                  //      student.Id = Convert.ToInt32(row["id"]);
                        student.Name = row["name"].ToString();
                        student.Password = row["password"].ToString();
                        student.Email = row["email"].ToString();
                        student.Class = row["class"].ToString();
                        student.Section = row["section"].ToString();
                        student.Rollno = Convert.ToInt32(row["rollno"]);
                        student.Teacher = row["teacher"].ToString();
                        student.College = row["college"].ToString();
                    }
                    return student;
                }


            }
            catch (Exception) { throw; }
            // catch(Exception ex) {
            //  return InternalSErverError( new CusomtError() { status: 500, errromessage: ex.tostring() })
            // }
            return NoContent();

        }

        [HttpPut]
        public ActionResult<StudentDetails> UpdatePassword(StudentDetails student)
        {
            try
            {
                SqlConnection con = new SqlConnection("server=apinp-elpt48905\\sqlexpress01;database=students;integrated security=false;user id=sa;password=guvi;");
                //sqlconnection connection = new sqlconnection(connectionstring);
                con.Open();
                string query = $"UPDATE [dbo].[student_details] SET [password] = '{student.Password}' WHERE rollno='{student.Rollno}'";

                SqlCommand cmd = new SqlCommand(query, con);
                var row = cmd.ExecuteReader();
                if (row.HasRows)
                {
                    //List<StudentDetails> students = new List<StudentDetails>();
                    //StudentDetails student = null;
                    if (row.Read())
                    {
                        return student;
                    }
               
                }


            }
            catch (Exception) { throw; }
            // catch(Exception ex) {
            //  return InternalSErverError( new CusomtError() { status: 500, errromessage: ex.tostring() })
            // }
            return NoContent();
        }
    }
}
