﻿using System.Data.SqlClient;
using System.Security.Permissions;

namespace dbapp.Repository
{
    public static class Connection
    {
        public static SqlConnection GetConnection()
        {
            SqlConnection connection = null;
            if (connection == null)
            {
                connection = new SqlConnection("server=apinp-elpt48905\\sqlexpress01;database=teachers;integrated security=false;user id=sa;password=guvi;");
            }
            return connection;
        }

        public static SqlConnection GetStudentConnection()
        {
            SqlConnection connection2 = null;
            if (connection2 == null)
            {
                connection2 = new SqlConnection("server=apinp-elpt48905\\sqlexpress01;database=students;integrated security=false;user id=sa;password=guvi;");
            }
            return connection2;
        }
        public static SqlConnection GetAttendanceConnection()
        {
            SqlConnection connection3 = null;
            if (connection3 == null)
            {
                connection3 = new SqlConnection("server=apinp-elpt48905\\sqlexpress01;database=attendancedeets;integrated security=false;user id=sa;password=guvi;");
            }
            return connection3;
        }
    }
}
