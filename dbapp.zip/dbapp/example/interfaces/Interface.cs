﻿namespace example.interfaces
{
    public interface Interface
    {
        public int Sid { get; set; }
        public string Name { get; set; }
        public string Pwd { get; set; }

        public string Dept { get; set; }
    }
}
