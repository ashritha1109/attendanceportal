﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace example.Controllers
{
    [ApiController]
    [Route("example/v1/student")]
    public class Student
    {
        public int Sid { get; set; }
        public string Name { get; set; }
        public string Dept { get; set; }

        public string Pwd { get; set; }

        public Address address { get; set; }
    }
    public class Address
    {
        public int No { get; set; }
        public string Street { get; set; }
    }
    public class WeatherForecastController : ControllerBase
    {
       

        [HttpGet]
        public ActionResult Get()
        {
            MongoClient client = new MongoClient("mongodb+srv://Ashritha:Lakshmiasi%4011@cluster0.pyinbvp.mongodb.net/test");
            var currentDb = client.GetDatabase("student");
            //  currentDb.CreateCollection("studentDetails");

            //insert

            var collection = currentDb.GetCollection<Student>("studentDetails");

            collection.InsertOne(new Student() { Sid = 2, Name = "jayanthi", Dept = "cse", Pwd = "1234" });
            return Ok("student added");
        }
    }
}
